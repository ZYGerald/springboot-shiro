package cc.mrbird.common.util;

public class Constant {

	static final String XLSX_SUFFIX = ".xlsx";

	static final String XLSX_CONTENT_TYPE = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
}
