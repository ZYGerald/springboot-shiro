package cc.mrbird.job.dao;

import cc.mrbird.common.config.MyMapper;
import cc.mrbird.job.domain.JobLog;

public interface JobLogMapper extends MyMapper<JobLog> {
}