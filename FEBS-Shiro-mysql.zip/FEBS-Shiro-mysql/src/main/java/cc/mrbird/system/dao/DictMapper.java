package cc.mrbird.system.dao;

import cc.mrbird.common.config.MyMapper;
import cc.mrbird.system.domain.Dict;

public interface DictMapper extends MyMapper<Dict> {
}