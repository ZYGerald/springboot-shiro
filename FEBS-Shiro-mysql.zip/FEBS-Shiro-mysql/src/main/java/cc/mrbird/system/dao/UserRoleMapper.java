package cc.mrbird.system.dao;

import cc.mrbird.common.config.MyMapper;
import cc.mrbird.system.domain.UserRole;

public interface UserRoleMapper extends MyMapper<UserRole> {
}