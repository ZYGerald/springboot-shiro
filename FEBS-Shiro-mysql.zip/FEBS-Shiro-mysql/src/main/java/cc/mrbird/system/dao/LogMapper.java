package cc.mrbird.system.dao;

import cc.mrbird.common.config.MyMapper;
import cc.mrbird.system.domain.SysLog;

public interface LogMapper extends MyMapper<SysLog> {
}